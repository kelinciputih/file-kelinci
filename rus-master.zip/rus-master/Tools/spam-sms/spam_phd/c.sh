z="
";Jz='1m]\';Lz='32;1';Iz='[39;';Cz='33[3';Az='echo';Dz='9;1m';Pz='..."';Bz=' "\0';Fz='3[32';Ez='[\03';Kz='033[';Gz=';1m√';Nz='M SU';Hz='\033';Mz='mSPA';Oz='CESS';
eval "$Az$z$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$z$Az" 
