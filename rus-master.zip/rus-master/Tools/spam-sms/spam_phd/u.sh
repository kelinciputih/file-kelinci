z="
";Ez='╚═══';Dz='4;1m';Cz='33[3';Fz='════';Az='echo';Gz='══╝"';Bz=' "\0';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Fz$Fz$Fz$Fz$Fz$Fz$Fz$Gz" 
