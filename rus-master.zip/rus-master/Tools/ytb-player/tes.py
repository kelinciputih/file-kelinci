import os, sys

def pilih():
	os.system("ytb "+ serch)
	
	
serch = raw_input("\n\033[39;1m[\033[32;1m+\033[39;1m]MASUKAN JUDUL LAGU\033[31;1m:\033[32;1m ")
print "wait..."

pilih()
	