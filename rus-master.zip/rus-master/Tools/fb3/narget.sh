######################################
# Thank You Allah Swt..              #
# Thanks My Team : Black Coder Crush #
# Thnks You All My Friends me.       #
# Thanks All Member BCC :            #
# Leader : M.Daffa                   #
# CO Founder : Mr.Tr3v!0n            #
# CO Leader : Akin                   #
# CO : Holilul Anwar                 #
# Zumbailee,Febry, Bima, Accil, Alfa #
# Ardi Bordir  Raka, Wahyu Andika.   #
# Mr.OO3T, Yulia Febriana, Sadboy,   #
# Cyto Xploit, Sazxt, Minewizard,    #
# Riki, Omest                        #
######################################
z="
";qBz='╚═══';Uz='m1="';sBz='p1} ';hBz='╩ ╩ ';nz='${p1';CBz='════';vBz='{m}:';lBz='═╝╚═';iz='{p1}';ABz='k}  ';jBz=' ╚  ';hz='  ┌$';nBz='╚═╝╚';mz='{m}◣';vz='  ~ ';Lz='34;1';DBz='═══╗';IBz=' ${b';MCz='on2 ';dz=' "${';WBz='}╠╣ ';PBz='m} ╠';Sz='p1="';Gz='h="\';XBz='╠═╣║';ECz='}Bla';GBz='╗╔═╗';Ez='m="\';DCz=':${b';HBz='╦╔═ ';SBz='╠╩╗$';BCz='Team';ACz='m}|$';Kz='b="\';Yz='hi="';Wz='p2="';YBz='  ║╣';UBz='▇▇▇═';wBz='Mr.T';CCz='${m}';ez='h}  ';pz='m}◢$';EBz='m} ╦';az='clea';fz='    ';JBz='}╔═╗';bBz=' ║╠╩';aBz='║ ║║';KBz='╔═╗╔';yBz='0n${';jz='∩${h';lz='k}($';Zz='[40;';Jz='33;1';oz='}_${';kBz='╩ ╩╚';gBz='╩╚═╝';dBz='			"';oBz='═╝╩ ';mBz='╝╚═╝';rBz='═══╝';yz='"';tBz=' Aut';HCz=' Cru';ZBz=' ╠╩╗';cz='echo';xBz='r3v!';kz='}┐${';tz='1}∩$';Dz='m"';OBz='═"';Tz='[37;';Rz='1m"';Vz='[38;';pBz='╩"';Xz='[39;';FBz=' ╦╔═';Nz='35;1';BBz='╔═══';rz='${h}';Iz='k="\';qz='{k})';fBz=' ╩╩ ';eBz='m} ╩';Pz='\033';LBz='═╗╔═';Bz='033[';Qz='[36;';bz='r';LCz='pyth';NBz='═╗╦╔';Hz='32;1';cBz='╗			';iBz='${b}';NCz='a.py';Fz='31;1';wz='~  $';xz='v3.0';gz=' ~ ~';Cz='30;1';MBz='╗╔╗ ';RBz='╣║  ';VBz='─${b';Az='a="\';ICz='sh"';uz='{h}┐';uBz='hor$';QBz='═╣╠═';JCz='k} <';GCz='oder';Mz='c="\';Oz='pu="';sz='┌${p';FCz='ck C';TBz='{h}┣';KCz='>"';
eval "$Az$Bz$Cz$Dz$z$Ez$Bz$Fz$Dz$z$Gz$Bz$Hz$Dz$z$Iz$Bz$Jz$Dz$z$Kz$Bz$Lz$Dz$z$Mz$Bz$Nz$Dz$z$Oz$Pz$Qz$Rz$z$Sz$Pz$Tz$Rz$z$Uz$Pz$Vz$Rz$z$Wz$Pz$Xz$Rz$z$Yz$Pz$Zz$Rz$z$az$bz$z$cz$dz$ez$fz$fz$gz$hz$iz$jz$kz$lz$mz$nz$oz$pz$qz$rz$sz$tz$uz$vz$wz$iz$xz$yz$z$cz$dz$ABz$BBz$CBz$CBz$CBz$CBz$CBz$CBz$CBz$CBz$DBz$yz$z$cz$dz$EBz$FBz$GBz$HBz$fz$IBz$JBz$KBz$LBz$MBz$KBz$NBz$OBz$z$cz$dz$PBz$QBz$RBz$SBz$TBz$UBz$VBz$WBz$XBz$YBz$ZBz$aBz$bBz$cBz$dBz$z$cz$dz$eBz$fBz$gBz$hBz$fz$iBz$jBz$kBz$lBz$mBz$nBz$oBz$pBz$z$cz$dz$ABz$qBz$CBz$CBz$CBz$CBz$CBz$CBz$CBz$CBz$rBz$yz$z$cz$dz$sBz$tBz$uBz$vBz$iBz$wBz$xBz$yBz$ACz$iz$BCz$CCz$DCz$ECz$FCz$GCz$HCz$ICz$z$cz$dz$JCz$CBz$CBz$CBz$CBz$CBz$CBz$CBz$CBz$CBz$CBz$KCz$z$LCz$MCz$NCz$z$cz$z$cz" 
